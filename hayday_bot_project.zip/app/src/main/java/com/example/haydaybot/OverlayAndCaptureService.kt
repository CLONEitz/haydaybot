package com.example.haydaybot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import kotlinx.coroutines.*

class OverlayAndCaptureService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingButton: Button
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var isPaused = true

    private var screenWidth = 1920
    private var screenHeight = 1080
    private var screenDensity = 320

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        iniciarForegroundNotification()
        criarBotaoFlutuante()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data: Intent = intent.getParcelableExtra("DATA") ?: return START_NOT_STICKY

        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)

        iniciarImageReader()
        iniciarLoopAutomacao()

        return START_STICKY
    }

    private fun criarBotaoFlutuante() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingButton = Button(this).apply {
            text = "▶ PLAY"
            setOnClickListener {
                isPaused = !isPaused
                text = if (isPaused) "▶ PLAY" else "⏸ PAUSE"
            }
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 100
        }

        windowManager.addView(floatingButton, params)
    }

    private fun iniciarImageReader() {
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "HayDayCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
    }

    private fun iniciarLoopAutomacao() {
        serviceScope.launch {
            while (isActive) {
                if (isPaused) {
                    delay(200)
                    continue
                }
                // Exemplo de automação segura em loop: aguarda e mantém o serviço ativo
                delay(1000)
            }
        }
    }

    private fun iniciarForegroundNotification() {
        val channelId = "hayday_bot_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "HayDay Bot Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("HayDay Bot Ativo")
            .setContentText("Capturando tela e aguardando comando...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        virtualDisplay?.release()
        mediaProjection?.stop()
        if (::floatingButton.isInitialized) windowManager.removeView(floatingButton)
    }
}
